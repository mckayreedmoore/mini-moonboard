"""Native frame iteration with an explicit finite-Coulomb floor scenario.

This changes the former switched no-slip support law. Each foot has elastic
initial tangential resistance capped by mu times its recovered positive normal
reaction. It is a monotonic, zero-initial-slip scenario, not a cyclic friction
history or measured floor qualification. Normal contact and numerical gates
remain unchanged. Convergence alone does not qualify member resistance.
"""
import hashlib
import json
import math
import os
import pickle
import subprocess
from pathlib import Path

import numpy as np

from fea import current_response_run as base
from fea.current_response_materials import connection_stiffnesses, materials
from fea.current_response_model import prepare


def sources():
    result = base.source_hashes()
    path = Path(__file__).resolve().relative_to(Path.cwd())
    result[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


LOADED_SOURCES = sources()


def coulomb_secant(slip_xy_mm, normal_n, mu, elastic_n_per_mm):
    """Return restoring force and secant for a circular elastic-slip force cap."""
    slip = np.asarray(slip_xy_mm, dtype=float)
    if (slip.shape != (2,) or not np.all(np.isfinite(slip))
            or not all(math.isfinite(x) for x in (normal_n, mu, elastic_n_per_mm))
            or normal_n < 0 or mu <= 0 or elastic_n_per_mm <= 0):
        raise ValueError('Require finite slip, nonnegative normal and positive mu/stiffness')
    bound = mu*normal_n
    magnitude = float(np.linalg.norm(slip))
    stiffness = min(elastic_n_per_mm, bound/magnitude) if magnitude else elastic_n_per_mm
    if normal_n == 0:
        stiffness = 0.
    return -stiffness*slip, stiffness


def floor_law_check(record, data, report, mu, elastic, tolerance_n=.01):
    """Recover actual slip even for zero-stiffness or omitted tangent springs."""
    displacement = base.frame.panel_kernel.read_blocks(data)['displacements']
    rows = {}
    physical = report['physical_connection_forces']
    for name, original in elastic.items():
        springs = [row for row in record['springs'] if row['name'] == name]
        if len(springs) != 2 or {row['dof'] for row in springs} != {1, 2}:
            raise ValueError('Require exactly two physical tangent springs per foot')
        body = physical[name]['first']
        normal = sum(max(0., row['force_on_first_xyz_n'][2]) for row in physical.values()
                     if row['first'] == body and row['second'] == 'floor' and 'scalar_normal' in row)
        slip = np.zeros(2)
        for spring in springs:
            a, b = spring['nodes']
            index = spring['dof']-1
            slip[index] = displacement[a][index]-displacement[b][index]
        target, secant = coulomb_secant(slip, normal, mu, original)
        actual = np.asarray(physical[name]['force_on_first_xyz_n'][:2])
        radius = float(np.linalg.norm(physical[name]['force_rounding_radius_xyz_n'][:2]))
        residual = float(np.linalg.norm(actual-target))
        excess = max(0., float(np.linalg.norm(actual))-mu*normal)
        rows[name] = {'body':body, 'normal_n':normal, 'slip_xy_mm':slip.tolist(),
            'force_xy_n':actual.tolist(), 'expected_force_xy_n':target.tolist(),
            'force_residual_n':residual, 'coulomb_excess_n':excess,
            'force_rounding_radius_n':radius, 'next_secant_n_per_mm':secant,
            'state':'open' if normal == 0 else 'stick' if secant == original else 'slip',
            'passed':residual <= tolerance_n+radius and excess <= tolerance_n+radius}
    if not rows:
        raise ValueError('Require current explicit foot tangent connections')
    return {'mu_assumed':mu, 'force_tolerance_n':tolerance_n, 'feet':rows,
            'passed':all(row['passed'] for row in rows.values()),
            'scope':__doc__}


def run(output, *, module, mu, expected_candidate=None, bolt_stiffness=None,
        max_cycles=80, damping=.5, initial_contact_names=None, **parameters):
    """Serial native solves; damp only the search, independently audit final law."""
    if not math.isfinite(mu) or mu <= 0 or not 0 < damping <= 1 or max_cycles < 1:
        raise ValueError('Require positive finite mu, iteration budget and damping in (0,1]')
    before = sources()
    if before != LOADED_SOURCES:
        raise ValueError('Restart Coulomb runner after source changes')
    expected_candidate = expected_candidate or module.KEY
    stiffnesses = {**connection_stiffnesses(), 'floor':1.e5, 'bearing':1.e6, 'seating_per_area':100.}
    if bolt_stiffness is not None:
        stiffnesses['bolt'] = dict(bolt_stiffness)
    structure, metadata = prepare(module, expected_candidate=expected_candidate,
        materials=materials(), stiffnesses=stiffnesses, **parameters)
    if before != sources():
        raise ValueError('Source changed during native preparation')
    directory = Path(output)
    directory.mkdir(parents=True, exist_ok=False)
    for name, sha in before.items():
        content = Path(name).read_bytes()
        if hashlib.sha256(content).hexdigest() != sha:
            raise ValueError('Source changed before snapshot: '+name)
        target = directory/'source_snapshots'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    with (directory/'model.pkl').open('wb') as stream:
        pickle.dump({'model':(structure, metadata), 'source_sha256':before}, stream)
    elastic = {row['name']:row['stiffness_n_per_mm'] for row in structure.springs
               if row['name'].endswith('_friction')}
    normal_names = {row['name'] for row in structure.springs
                    if row['bearing_closed_assumption'] and row['name'] not in elastic}
    active = set(normal_names) if initial_contact_names is None else set(initial_contact_names)
    if not active <= normal_names:
        raise ValueError('Initial normal contacts must belong to this candidate')
    active.update(elastic)
    history = []
    report = {}
    for iteration in range(max_cycles):
        job = directory/f'cycle-{iteration:02d}'
        job.mkdir()
        record = base.frame.record_structure(structure, metadata, active)
        (job/'input.json').write_text(json.dumps(record, indent=2)+'\n')
        (job/'frame.inp').write_text(structure.deck(active_bearings=active, stress=False).replace(
            '*END STEP', '*NODE FILE,OUTPUT=3D\nU\n*END STEP'))
        command = ['docker','run','--rm','--network=none','--cpus=1','--memory=4g',
            '--user',f'{os.getuid()}:{os.getgid()}','-e','OMP_NUM_THREADS=1',
            '-v',f'{job.resolve()}:/output','-w','/output',base.frame.panel_kernel.IMAGE,
            'timeout','240s','ccx','-i','frame']
        native = subprocess.run(command, capture_output=True, text=True, timeout=260, check=False)
        log = native.stdout+native.stderr
        (job/'frame.log').write_text(log)
        if native.returncode or '*ERROR' in log.upper():
            raise ValueError('Native Coulomb iteration failed; inspect '+str(job/'frame.log'))
        data = (job/'frame.dat').read_text()
        report = base.assess(record, data, (job/'frame.frd').read_text(), (job/'frame.12d').read_text(),
                             expected_candidate=expected_candidate)
        friction = floor_law_check(record, data, report, mu, elastic)
        report['floor_friction_law'] = friction
        report['floor_scope'] = __doc__
        (job/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
        history.append({'directory':job.name, 'normal_contact_passed':report['closed_bearing_assumption_passed'],
            'friction_law_passed':friction['passed'],
            'peak_friction_residual_n':max(row['force_residual_n'] for row in friction['feet'].values())})
        print(json.dumps(history[-1]), flush=True)
        if report['closed_bearing_assumption_passed'] and friction['passed']:
            report['contact_active_set_converged'] = True
            report['termination'] = 'Normal contact and explicit Coulomb force law converged'
            break
        # The target force tends continuously to zero with normal reaction.
        # Secant damping is an iteration aid only; it is never a physical pass.
        active = base.next_contact_names(report['bearings'], 'all')
        for name, row in friction['feet'].items():
            target = row['next_secant_n_per_mm']
            selected = [spring for spring in structure.springs if spring['name'] == name]
            previous = selected[0]['stiffness_n_per_mm']
            updated = 0. if target == 0. else (1.-damping)*previous+damping*target
            for spring in selected:
                spring['stiffness_n_per_mm'] = updated
            if updated > 0:
                active.add(name)
    report.setdefault('contact_active_set_converged', False)
    report.setdefault('termination', 'Coulomb/contact iteration budget exhausted')
    report.update(candidate=metadata['candidate'], angle_stations=metadata['angle_stations'],
        parameters={key:metadata.get(key) for key in ('hold','pounds','force_xyz_n','standoff_from_front_mm',
            'stiffnesses','materials','equipment_kg','frame_size_mm','panel_size_mm','leg_bolt_scale',
            'leg_floor_grid','floor_rail_support','native_panel_cutouts','leg_floor_pressure_assumption',
            'leg_joint_assumption','header_bearing_assumption')}, source_sha256=before,
        contact_cycles=history, solver_image=base.frame.panel_kernel.IMAGE,
        contact_update_strategy='finite_coulomb_damped_secant', initial_contact_names=initial_contact_names,
        assumptions=__doc__, qualified_for_design=False)
    report['parameters']['floor_friction_assumption'] = {'mu':mu, 'elastic_tangent_n_per_mm':elastic,
        'monotonic_zero_initial_slip':True, 'measured_floor':False, 'original_no_slip_basis':False}
    report['numerically_accepted'] = all(report.get(key,False) for key in (
        'contact_active_set_converged','global_equilibrium_passed','member_equilibrium_passed','mpc_check_passed'))
    if before != sources():
        raise ValueError('Producer source changed during solve')
    report['artifact_sha256'] = {str(path.relative_to(directory)):hashlib.sha256(path.read_bytes()).hexdigest()
        for path in directory.rglob('*') if path.is_file()}
    (directory/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    return report
