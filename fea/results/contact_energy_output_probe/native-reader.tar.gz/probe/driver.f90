program contact_energy_output_probe
  implicit none
  integer :: mi(3)=(/4,3,1/), ipkon(8)=0, kon(32)=0, ielmat(1,8)=1
  integer :: ielprop(8)=0, nelemload(2,1)=0, ithermal(2)=0, nrhcon(1)=0
  integer :: ipobody(2,8)=0, ibody(3,1)=0
  integer :: ii=1, nelem=2, ne=2, nodes=0, ielem=101, iface=2, mortar=1
  integer :: nload=0, ntmat=1, nbody=0, case_id, igauss, j
  integer, parameter :: original_extent=1
  character(len=6) :: prlab(1)='CELS  '
  character(len=8) :: lakon(8)='C3D10   '
  character(len=20) :: sideload(1)=' '
  real(8) :: ener(2,4,8)=0, co(3,12)=0, stx(6,4,8)=0, thicke(1,32)=0
  real(8) :: prop(1)=0, xload(2,1)=0, rhcon(0:1,1,1)=0, t1(12)=0
  real(8) :: vold(0:3,12)=0, xbody(7,1)=0
  real(8) :: energytot=0, volumetot=0, enerkintot=0, bhetot=0, xmasstot=0
  real(8) :: xinertot(6)=0, cg(3)=0
  ! ESPRNGC6 matches an ordinary TRI6-to-TRI6 S2S contact element.
  lakon(nelem)='ESPRNGC6'
  ipkon(nelem)=1
  kon(1)=12
  do j=1,12
    kon(j+1)=j
  enddo
  close(5)
  open(5,file='probe.dat',status='new',action='write')
  do case_id=1,3
    igauss=7
    if(case_id==1) igauss=1
    kon(14)=igauss
    kon(15)=1
    kon(16)=igauss
    ener=0
    ! Controlled setup mirrors the documented writer layout, not its execution.
    ener(1,1,original_extent+igauss)=7.5d0
    if(case_id==3) ener(1,1,nelem)=2.25d0
    energytot=0
    call printoutelem(prlab,ipkon,lakon,kon,co,ener,mi,ii,nelem, &
      energytot,volumetot,enerkintot,ne,stx,nodes,thicke,ielmat, &
      ielem,iface,mortar,ielprop,prop,sideload,nload,nelemload,xload, &
      bhetot,xmasstot,xinertot,cg,ithermal,rhcon,nrhcon,ntmat,t1, &
      vold,ipobody,ibody,xbody,nbody)
    write(6,'(4(i0,1x),3(es24.16,1x))') case_id,nelem,igauss, &
      original_extent+igauss,ener(1,1,original_extent+igauss), &
      ener(1,1,nelem),energytot
  enddo
  close(5)
end program
