subroutine beamintscheme()
  implicit none
  error stop 'UNREACHABLE beamintscheme'
end subroutine

subroutine linscal10()
  implicit none
  error stop 'UNREACHABLE linscal10'
end subroutine

subroutine lintemp()
  implicit none
  error stop 'UNREACHABLE lintemp'
end subroutine

subroutine lintemp_th1()
  implicit none
  error stop 'UNREACHABLE lintemp_th1'
end subroutine

subroutine materialdata_rho()
  implicit none
  error stop 'UNREACHABLE materialdata_rho'
end subroutine

subroutine nident2()
  implicit none
  error stop 'UNREACHABLE nident2'
end subroutine

subroutine shape10tet()
  implicit none
  error stop 'UNREACHABLE shape10tet'
end subroutine

subroutine shape15w()
  implicit none
  error stop 'UNREACHABLE shape15w'
end subroutine

subroutine shape20h()
  implicit none
  error stop 'UNREACHABLE shape20h'
end subroutine

subroutine shape4tet()
  implicit none
  error stop 'UNREACHABLE shape4tet'
end subroutine

subroutine shape6tri()
  implicit none
  error stop 'UNREACHABLE shape6tri'
end subroutine

subroutine shape6w()
  implicit none
  error stop 'UNREACHABLE shape6w'
end subroutine

subroutine shape8h()
  implicit none
  error stop 'UNREACHABLE shape8h'
end subroutine

subroutine shape8hr()
  implicit none
  error stop 'UNREACHABLE shape8hr'
end subroutine

subroutine shape8hu()
  implicit none
  error stop 'UNREACHABLE shape8hu'
end subroutine

subroutine shape8q()
  implicit none
  error stop 'UNREACHABLE shape8q'
end subroutine
