import math

import pytest

from fea.independent_ply_control import E, LENGTH, audit, deck, verify_serialized


@pytest.mark.parametrize("n", [2,4])
@pytest.mark.parametrize("independent", [False,True])
def test_pure_bending_control(n,independent):
    text,context = deck(n,independent)
    verify_serialized(text,context)
    if independent:
        a,b = [set(p["nodes"]) for p in context["plies"]]
        assert not a & b
        assert {context["nodes"][n] for n in a} & {context["nodes"][n] for n in b}
    for case in context["cases"]:
        for ply,exact in zip(context["plies"],case["exact"],strict=True):
            k = exact["moment_nmm"]/(E*exact["inertia_mm4"])
            # Exact quadratic axial field; the same traction integration must
            # reproduce exact half-work independent of face triangulation.
            work = sum(case["loads"].get(n,0.)*k*(context["nodes"][n][case["axis"]]-(ply["center_x"] if case["axis"]==0 else 0.))*LENGTH/2
                       for n in ply["nodes"] if context["nodes"][n][2]==LENGTH)
            assert math.isclose(work,exact["energy_nmm"],rel_tol=1e-12,abs_tol=1e-12)
    with pytest.raises(ValueError):
        verify_serialized(text+"*TIE\n",context)
    with pytest.raises(ValueError):
        verify_serialized(text.replace("*CLOAD,OP=NEW","*CLOAD",1),context)
    with pytest.raises(ValueError):
        audit("",context)
